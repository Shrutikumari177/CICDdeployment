sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.ingenx.nauti.submitquotation.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  